function Customalert(){
    Window.alert("Welcome to the Demo Class");
}